package com.internship.changeit.model;

public enum Role {
    USER, MANAGER, ADMIN
}
