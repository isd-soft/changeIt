package com.internship.changeit.model;

public enum Status {
    ACTIVE, IN_PROGRESS, DONE, REJECTED, INACTIVE
}
