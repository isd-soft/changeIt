package com.internship.changeit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChangeitApplicationTests {

    @Test
    void contextLoads() {
    }

}
